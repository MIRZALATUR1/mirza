# BuildMart POS — Multi-Tenant SaaS (Hardware / Building Material Shops)

Ek hi app se multiple shops (tenants) apna alag-alag POS, inventory, billing aur reports
chala sakte hain. Naya user Google se login karta hai → naya business banata hai ya
existing business join karta hai (invite code se) → admin approve karta hai → tab access milta hai.

No build step chahiye — pure static `index.html`, isliye Cloudflare Pages pe deploy karna sabse simple hai.

---

## 1. Firebase Setup (aapke pass project already hai)

1. [Firebase Console](https://console.firebase.google.com) → apna project kholo.
2. **Authentication → Sign-in method → Google** ko enable karo.
3. **Authentication → Settings → Authorized domains** me apna Cloudflare Pages domain add karo
   (e.g. `buildmart.pages.dev` aur baad me apna custom domain bhi).
4. **Firestore Database** banao (agar nahi bana) → Production mode.
5. **Project Settings → General → Your apps → Web app** se config lo aur
   `index.html` ke top wale `window.FIREBASE_CONFIG` block me paste karo:

   ```js
   window.FIREBASE_CONFIG = {
     apiKey: "...",
     authDomain: "...",
     projectId: "...",
     storageBucket: "...",
     messagingSenderId: "...",
     appId: "..."
   };
   ```

   (Firebase web API key secret nahi hoti — security asli me Firestore Rules se aati hai,
   jo already `firestore.rules` me diye hain.)

6. Firestore Rules deploy karo (Firebase CLI se, one-time):

   ```bash
   npm install -g firebase-tools
   firebase login
   firebase use --add        # apna project select karo
   firebase deploy --only firestore:rules,firestore:indexes
   ```

   (Agar CLI use nahi karna, to `firestore.rules` ka content copy karke
   Firebase Console → Firestore → Rules tab me paste bhi kar sakte ho.)

---

## 2. GitHub

```bash
git init
git add .
git commit -m "BuildMart POS - multi-tenant SaaS"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

---

## 3. Cloudflare Pages (deploy from GitHub, no build needed)

1. Cloudflare Dashboard → **Workers & Pages → Create → Pages → Connect to Git**.
2. Apna GitHub repo select karo.
3. Build settings:
   - **Framework preset:** None
   - **Build command:** *(khaali chhod do)*
   - **Build output directory:** `/`
4. **Save and Deploy**.
5. Deploy hone ke baad jo domain milega (e.g. `buildmart.pages.dev`), usko wapas
   Firebase Console → Authentication → Authorized domains me add karna mat bhoolna
   (varna Google login "unauthorized domain" error dega).

Har baar jab tum GitHub `main` branch pe push karoge, Cloudflare Pages automatically
rebuild + redeploy kar dega.

---

## 4. Pehli baar app use karna

1. Deployed URL kholo → **Continue with Google** se login karo.
2. **"Naya Business Shuru Karein"** dabao, shop ka naam do → tum automatically
   us business ke **Owner (admin)** ban jaoge.
3. Sidebar → **User Management** me apna **Invite Code** milega — ye staff ko do.
4. Staff Google se login karke **"Existing Business Join Karein"** me wahi code dalega →
   uska request **Pending** me chala jayega.
5. Admin, **User Management** me jaake **Approve as Staff / Approve as Admin** dabayega —
   tabhi wo user login kar payega.
6. **Settings** tab (admin only) me business name, address, mobile, GSTIN update karo —
   ye printed bills/quotations pe show hota hai.

---

## Data Model (Firestore)

```
orgs/{orgId}
  name, address, mobile, gstin, ownerId, inviteCode, createdAt

orgs/{orgId}/products/{productId}
  name, category, unit, priceBuy, priceSell, stock, gst, discount

orgs/{orgId}/sales/{saleId}
  date, customer, cart, grandTotal, totalProfit, billType, paymentMode,
  staffUid, staffName, staffEmail, partyId

orgs/{orgId}/parties/{partyId}          (customers you gave udhar to / suppliers you owe)
  name, mobile, type (customer|supplier), balance, createdAt
  orgs/{orgId}/parties/{partyId}/transactions/{txnId}
    type (sale_credit|purchase_credit|payment_received|payment_made|opening_balance),
    amount, note, date, billId, staffUid, staffName

orgs/{orgId}/expenses/{expenseId}        (used for Profit & Loss)
  category, amount, note, date, createdAt

users/{uid}
  uid, name, email, photoURL, orgId, role (owner|admin|staff),
  status (pending|active|disabled), permissions (staff only)
```

Har shop ka data `orgs/{orgId}/...` ke andar isolated hai — Firestore Rules ensure
karte hain ki koi bhi user sirf apne hi org ka data padh/likh sake.

---

## Ready-Made Material Catalog (Quick Pick)

Inventory ke "Add New Material" form me category chunte hi ek **Quick Pick** panel
khulta hai jisme us category ke common items pehle se diye hain:

- **Cement** — OPC 43/53, PPC, White Cement (brands: UltraTech, ACC, Ambuja, Shree, JK, Birla, Ramco, Dalmia)
- **Steel** — TMT Bar, MS Angle/Flat/Pipe/Channel, Binding Wire (sizes: 6mm–32mm; brands: Tata Tiscon, JSW, SAIL, Kamdhenu, Rathi)
- **Hardware** — Nails/Khile, Screws, Hinges, Tower Bolt, Handle, Padlock, M-Seal, Tape, Hammer, Wire Mesh
- **Plumbing** — CPVC/PVC Pipe, Elbow, Tee, Coupler, Ball Valve, Bib Cock (brands: Astral, Finolex, Supreme, Prince)
- **Paint** — Interior/Exterior Emulsion, Enamel, Primer, Distemper, Wall Putty (brands: Asian Paints, Berger, Nerolac, Dulux)
- **Electrical** — Wire, MCB, Switch, Socket, LED Bulb, Tube Light, Fan (brands: Havells, Anchor, Polycab, Finolex, Philips)
- **Bath Fitting** — Bib Cock, Angle Valve, Shower, Wash Basin, Commode, Basin Mixer (brands: Jaguar, Cera, Hindware, Parryware)
- **AAC Blocks** — 4"/6"/8"/9" (brands: Siporex, Magicrete, Biltech)

Item chuno → Size/Type aur Brand/Company dropdown se select karo → naam khud ban jata
hai (e.g. "12mm TMT Steel Bar - Tata Tiscon"). Brand aur Spec alag se bhi save hote
hain, isliye Inventory list me Brand/Size ke column bhi dikhte hain. Catalog me jo item
na mile, wo hamesha manually type kar sakte ho — koi restriction nahi hai.

## Dashboard Analysis

Dashboard ab sirf total revenue/profit nahi, poori category-wise picture dikhata hai:
- **Category Performance** table — har category ka stock value, kitne items low hain,
  kitni units bikin, revenue, aur us category ka **Hero Product**.
- **Low Stock Alert** — jo bhi material 10 se kam bacha hai, uski live list.

## Multi-Language (English / हिंदी / मराठी)

Sidebar me har user apni bhasha chun sakta hai (business name ke neeche dropdown).
Ye Inventory aur menu ko translate karta hai — category/unit naam bhi translate ho
jate hain, lekin database me hamesha English hi save hota hai taaki data consistent rahe.

---

## Udhar Khata (Credit Book)

- **POS** me "Payment Mode: Udhar" chunte hi customer ka naam le kar sale complete
  hone par uska record automatically **Khata Book → Customers** me chala jata hai.
- **Inventory** me stock add karte waqt (admin only) "Udhar (Supplier Credit)" chun
  kar supplier ka naam do to wo **Khata Book → Suppliers** me payable ke roop me
  chala jata hai.
- **Khata Book** se hi payments record kar sakte ho (customer se payment mila /
  supplier ko payment diya), aur bina bill ke bhi manual udhar/payment entry kar
  sakte ho, ya opening balance ke saath naya party bana sakte ho.

## Profit & Loss

**Profit & Loss** tab (permission-gated) revenue, cost of goods sold, gross profit,
business expenses (rent/salary/transport/etc. — admin add karta hai), aur net profit
date-range ke saath dikhata hai.

## User Permissions

Admin/Owner ko hamesha full access hota hai. Staff approve karte waqt default
permissions milte hain: **POS (Sell)** aur **Inventory (Add Stock)**. Baad me
**User Management → Permissions** se admin fine-tune kar sakta hai ki wo staff
member kya-kya dekh/kar sakta hai:
- Sell (POS/Billing)
- Add / Restock Inventory
- View Sales Reports
- View Profit & Loss
- Manage Udhar Khata
- View Dashboard

---

## Security note (production ke liye)

Filhaal approval-logic client-side + Firestore Rules se enforce hoti hai, jo
zyadatar chhoti-medium SaaS ke liye theek hai. Agar aage chal ke zyada strict
control chahiye (e.g. billing/subscriptions, role escalation ko poori tarah
server-side lock karna), to ek Firebase Cloud Function add karke sensitive writes
(role/status changes) ko wahan se karwana best practice hoga.
